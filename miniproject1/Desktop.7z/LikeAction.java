package servlet;

@WebServlet("/LikeServlet")
public class LikeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private LikeDAO likeDAO = new LikeDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StringBuilder jsonBuffer = new StringBuilder();
        String line;
        while ((line = request.getReader().readLine()) != null) {
            jsonBuffer.append(line);
        }

        Gson gson = new Gson();
        LikeRequest likeRequest = gson.fromJson(jsonBuffer.toString(), LikeRequest.class);

        try {
            likeDAO.updateLike(likeRequest.isLiked);
            LikeVO likeVO = likeDAO.getLike();
            LikeResponse likeResponse = new LikeResponse(likeVO.getCount());
            String jsonResponse = gson.toJson(likeResponse);

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonResponse);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    private class LikeRequest {
        boolean isLiked;
    }

    private class LikeResponse {
        int count;

        LikeResponse(int count) {
            this.count = count;
        }
    }
}