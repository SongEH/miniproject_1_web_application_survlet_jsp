CREATE TABLE likes (
    id NUMBER PRIMARY KEY,
    count NUMBER
);

INSERT INTO likes (id, count) VALUES (1, 0);