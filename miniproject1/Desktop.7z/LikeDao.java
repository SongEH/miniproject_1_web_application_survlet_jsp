package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import vo.LikeVo;

public class LikeDao {
    public LikeVo getLike() throws SQLException {
        String sql = "SELECT * FROM likes WHERE id = 1";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            if (rs.next()) {
                int count = rs.getInt("count");
                return new LikeVo(1, count);
            }
        }
        return new LikeVo(1, 0); // 기본값
    }

    public void updateLike(boolean isLiked) throws SQLException {
        String sql = "UPDATE likes SET count = count + ? WHERE id = 1";
        int increment = isLiked ? 1 : -1;
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, increment);
            pstmt.executeUpdate();
        }
    }
}
